extends Node3D

const SAVE_PATH="user://cargofix_save.json"
var cash=15000
var reputation=5
var game_day=1
var hour=8.0
var order_active=false
var orders_completed=0
var parts_cost=900
var repair_price=2200
var player_ref:CharacterBody3D
var tool_level=0
var vehicle_level=0
var shop_level=0
var staff_count=0
var repair_stage=0
var repair_quality=50
var callout_fee=350
var total_revenue=0
var total_expenses=0
var business_rank=1
var milestone_paid=0
var repair_action_elapsed=0.0
var repair_stages=["Снять нижние винты","Прогреть и открыть дисплей","Отключить аккумулятор","Установить запчасть","Проверить функции"]
var job_model="iPhone 11"
var job_title="Замена аккумулятора"
var job_client="Алексей"
var job_address="ул. Байкальская, 12"
var client_position=Vector3(12,0,-12)
var city_rng=RandomNumberGenerator.new()
var message_cache=""

func _process(delta):
    if order_active:
        repair_action_elapsed += delta

func _ready():
    player_ref=$Player
    city_rng.randomize()
    create_city()
    create_client()
    load_game()
    update_hud()

func mat(color:Color)->StandardMaterial3D:
    var m=StandardMaterial3D.new()
    m.albedo_color=color
    return m

func create_city():
    # Asphalt main avenue, sidewalks, lane markings and a small park.
    var asphalt=mat(Color("#303842"))
    add_box("Main road",Vector3(9,.12,130),Vector3(0,.03,-27),asphalt)
    add_box("Cross road",Vector3(110,.12,8),Vector3(0,.04,-34),asphalt)
    var sidewalk=mat(Color("#9299a1"))
    for x in [-6.2,6.2]:
        add_box("Sidewalk",Vector3(2,.2,130),Vector3(x,.12,-27),sidewalk)
    var marking=mat(Color("#e8d99b"))
    for z in range(-82,24,12):
        add_box("Road marking",Vector3(.18,.025,4),Vector3(0,.11,z),marking)
    var colors=[Color("#7e9eaf"),Color("#d2b18b"),Color("#a2b59c"),Color("#b1a1c2"),Color("#c5cbd2")]
    for i in range(26):
        var side=-1 if i%2==0 else 1
        var depth=float(i/2)*12.5-75
        var width=city_rng.randf_range(5.2,8.2)
        var height=city_rng.randf_range(5,14)
        var x=side*city_rng.randf_range(11,22)
        var b=add_box("Building",Vector3(width,height,city_rng.randf_range(6,10)),Vector3(x,height/2,depth),mat(colors[i%colors.size()]))
        # colored storefront at street level
        if i%5==0:
            add_box("Shop front",Vector3(width*.72,2.2,.15),Vector3(x,1.25,depth+5),mat(Color("#4e8797")))
            var sign=Label3D.new()
            sign.text=["МАГАЗИН","АПТЕКА","КАФЕ","САЛОН"][i%4]
            sign.position=Vector3(x,3.2,depth+5.1)
            sign.font_size=34
            add_child(sign)
    # CargoFix workshop visual
    add_box("CargoFix shop",Vector3(8,4.5,7),Vector3(-16,2.25,-18),mat(Color("#254c67")))
    add_box("Shop glass",Vector3(4.5,2.4,.15),Vector3(-16,1.7,-14.45),mat(Color("#66b8d4")))
    var label=Label3D.new()
    label.text="CARGOFIX  |  РЕМОНТ"
    label.position=Vector3(-16,5,-14)
    label.font_size=42
    add_child(label)
    # Park landscaping
    add_box("Park lawn",Vector3(16,.15,17),Vector3(26,.08,-7),mat(Color("#4d8052")))
    for i in range(7):
        var px=19+city_rng.randf_range(0,13)
        var pz=-14+city_rng.randf_range(0,14)
        add_box("Tree trunk",Vector3(.45,2,.45),Vector3(px,1,pz),mat(Color("#65472e")))
        var crown=MeshInstance3D.new()
        var sphere=SphereMesh.new()
        sphere.radius=1.45
        sphere.height=2.9
        crown.mesh=sphere
        crown.material_override=mat(Color("#3e7951"))
        crown.position=Vector3(px,3,pz)
        add_child(crown)

func add_box(n:String,size:Vector3,pos:Vector3,material:Material)->MeshInstance3D:
    var node=MeshInstance3D.new()
    var mesh=BoxMesh.new()
    mesh.size=size
    node.mesh=mesh
    node.material_override=material
    node.position=pos
    node.name=n
    add_child(node)
    # Solid collision for architecture; decorative objects remain visual only.
    if n=="Building" or n=="CargoFix shop" or n=="Shop front":
        var body=StaticBody3D.new()
        body.name="ArchitectureCollision"
        var shape=CollisionShape3D.new()
        var box=BoxShape3D.new()
        box.size=size
        shape.shape=box
        body.position=pos
        body.add_child(shape)
        add_child(body)
    return node

func create_client():
    var npc=Node3D.new()
    npc.name="ClientNPC"
    npc.position=client_position
    add_child(npc)
    var body=MeshInstance3D.new()
    var capsule=CapsuleMesh.new()
    capsule.radius=.36
    capsule.height=1.65
    body.mesh=capsule
    body.material_override=mat(Color("#d58b55"))
    body.position.y=.85
    npc.add_child(body)
    var head=MeshInstance3D.new()
    var sphere=SphereMesh.new()
    sphere.radius=.28
    sphere.height=.56
    head.mesh=sphere
    head.material_override=mat(Color("#e9bd98"))
    head.position.y=1.8
    npc.add_child(head)
    var marker=MeshInstance3D.new()
    var ring=CylinderMesh.new()
    ring.top_radius=.9
    ring.bottom_radius=.9
    ring.height=.07
    marker.mesh=ring
    marker.material_override=mat(Color("#42f59a"))
    marker.position.y=.08
    npc.add_child(marker)
    var tag=Label3D.new()
    tag.text="КЛИЕНТ"
    tag.position.y=2.4
    tag.font_size=32
    npc.add_child(tag)

func accept_order():
    if order_active:
        show_message("Заказ уже активен. Найди клиента на улице.")
        return
    var catalog=[
        ["iPhone 11","Замена аккумулятора","Алексей",850,1800],
        ["iPhone 12","Замена дисплея","Марина",1900,3900],
        ["iPhone XR","Замена заднего стекла","Дмитрий",1200,3200],
        ["iPhone 13","Замена аккумулятора","Ольга",1600,2900],
        ["iPhone 14 Pro","Диагностика камеры","Илья",2600,5200],
        ["iPhone 12 mini","Замена разъёма зарядки","Виктор",1450,3300],
        ["iPhone 13 Pro Max","Замена дисплея","Наталья",3400,6900],
        ["iPhone SE 2022","Замена аккумулятора","Павел",950,2100],
        ["iPhone 15","Диагностика после падения","Ксения",2200,4700],
        ["iPhone 11","Замена камеры","Егор",1300,3100],
        ["iPhone 14","Замена заднего стекла","София",2300,4800],
        ["iPhone 12","Чистка динамика","Антон",250,1400],
        ["iPhone 15 Pro","Замена аккумулятора","Вера",2800,5600],
        ["iPhone XR","Замена дисплея","Максим",1250,2900],
        ["iPhone 13 mini","Замена камеры","Дарья",1800,3900],
        ["iPhone 14 Pro Max","Диагностика Face ID","Роман",3000,6200],
        ["iPhone 15 Plus","Замена разъёма зарядки","Алина",2500,5100],
        ["iPhone 12 Pro","Замена аккумулятора","Сергей",1700,3500],
        ["iPhone 11 Pro","Замена дисплея","Екатерина",2100,4400],
        ["iPhone 16","Диагностика камеры","Михаил",3500,7200],
        ["iPhone 16 Pro","Замена дисплея","Анастасия",4800,9800],
        ["iPhone 14 Plus","Замена аккумулятора","Тимур",2100,4200],
        ["iPhone 13 Pro","Замена заднего стекла","Лидия",2500,5100],
        ["iPhone 12 Pro Max","Замена камеры","Глеб",2200,4600],
        ["iPhone 15 Pro Max","Замена дисплея","Полина",5200,10500],
        ["iPhone 16 Pro Max","Замена аккумулятора","Артур",3900,7900],
        ["iPhone 16e","Диагностика зарядки","Яна",2400,4900],
        ["iPhone 17","Замена аккумулятора","Владислав",4600,9300],
        ["iPhone 17 Pro","Замена дисплея","Мария",6200,12400],
        ["iPhone 17 Pro Max","Диагностика камеры","Денис",5800,11800],
        ["iPhone Air","Диагностика после падения","Элина",4300,8800],
        ["iPhone 17e","Замена разъёма зарядки","Борис",3700,7600],
        ["iPhone 11","Замена аккумулятора","Алексей",850,1800],
        ["iPhone 12","Замена дисплея","Марина",1900,3900],
        ["iPhone XR","Замена заднего стекла","Дмитрий",1200,3200],
        ["iPhone 13","Замена аккумулятора","Ольга",1600,2900],
        ["iPhone 14 Pro","Диагностика камеры","Илья",2600,5200]
    ]
    var item=catalog[city_rng.randi_range(0,catalog.size()-1)]
    job_model=item[0];job_title=item[1];job_client=item[2];parts_cost=item[3];repair_price=item[4]
    if cash<parts_cost:
        show_message("Не хватает средств на запчасть. Сейчас нужно "+str(parts_cost)+" ₽.")
        return
    cash-=parts_cost
    order_active=true
    repair_stage=0
    repair_quality=50
    repair_action_elapsed=0.0
    client_position=Vector3(city_rng.randf_range(9,15),0,city_rng.randf_range(-17,-8))
    $ClientNPC.position=client_position
    show_message("Заказ: "+job_model+" · "+job_title+". Деталь: "+str(parts_cost)+" ₽. Выезд: "+str(callout_fee)+" ₽ отдельно. Клиент "+job_client+" ждёт по адресу "+job_address+".")
    update_hud()
    save_game()

func interact():
    if not order_active:
        if player_ref.global_position.distance_to(Vector3(-16,0,-18))<7:
            show_message("Мастерская CargoFix. Здесь можно улучшать бизнес через меню.")
        else:
            show_message("Открой планшет, чтобы получить заявку.")
        return
    var distance=player_ref.global_position.distance_to(client_position)
    if distance>4.2:
        show_message("Клиент далеко: "+str(int(distance))+" м. Иди к зелёному маркеру.")
        return
    if repair_stage<repair_stages.size():
        var timing_bonus=8 if repair_action_elapsed<=3.0 else (-4 if repair_action_elapsed>9.0 else 2)
        var tool_bonus=4 if tool_level>0 else 0
        repair_quality=clamp(repair_quality+timing_bonus+tool_bonus,0,100)
        repair_action_elapsed=0.0
        show_message("Ремонт · "+str(repair_stage+1)+"/5: "+repair_stages[repair_stage]+" · качество "+str(repair_quality)+"%")
        repair_stage+=1
        if repair_stage==repair_stages.size():
            finish_order()
    update_hud()

func finish_order():
    var bonus=shop_level*300+tool_level*200
    var quality_multiplier=0.8+float(repair_quality)/250.0
    var final_payment=int((repair_price+bonus)*quality_multiplier)
    var received=final_payment+callout_fee
    cash+=received
    total_revenue+=received
    var rep_gain=3 if repair_quality>=85 else (2 if repair_quality>=55 else 1)
    reputation+=rep_gain
    orders_completed+=1
    order_active=false
    update_business_rank()
    show_message("Заказ закрыт: ремонт "+str(final_payment)+" ₽ + выезд "+str(callout_fee)+" ₽ = "+str(received)+" ₽. Качество "+str(repair_quality)+"%. Репутация +"+str(rep_gain)+".")
    update_hud()
    save_game()

func advance_time():
    hour+=2
    if hour>=20:
        hour=8
        game_day+=1
        var daily_cost=250+shop_level*450+staff_count*1000
        cash-=daily_cost
        total_expenses+=daily_cost
        var staff_income=staff_count*1800
        cash+=staff_income
        total_revenue+=staff_income
        if staff_count>0:
            show_message("Новый день · расходы "+str(daily_cost)+" ₽, доход мастера "+str(staff_income)+" ₽. Баланс дня "+str(staff_income-daily_cost)+" ₽.")
        else:
            show_message("Новый день · реклама/связь/расходы: −"+str(daily_cost)+" ₽. Принимай заявки!")
    else:
        show_message("Время прошло. Сейчас "+str(int(hour))+":00.")
    update_hud()
    save_game()

func update_business_rank():
    var new_rank=1
    if orders_completed>=3:new_rank=2
    if orders_completed>=8:new_rank=3
    if orders_completed>=18:new_rank=4
    if orders_completed>=35:new_rank=5
    if new_rank>business_rank:
        business_rank=new_rank
        var bonus=business_rank*2500
        cash+=bonus
        show_message("Уровень бизнеса повышен: "+rank_name()+"! Бонус развития +"+str(bonus)+" ₽.")
    # One-time milestone rewards.
    if orders_completed>=5 and milestone_paid<1:
        cash+=5000;milestone_paid=1
        show_message("Достижение: первые 5 ремонтов! Премия 5 000 ₽.")
    elif orders_completed>=15 and milestone_paid<2:
        cash+=12000;milestone_paid=2
        show_message("Достижение: 15 ремонтов! Премия 12 000 ₽.")
    elif orders_completed>=30 and milestone_paid<3:
        cash+=25000;milestone_paid=3
        show_message("Достижение: 30 ремонтов! Премия 25 000 ₽.")

func rank_name()->String:
    return ["Самозанятый","Мастер на выезде","Проверенный сервис","Мобильная команда","Сеть CargoFix"][clamp(business_rank-1,0,4)]

func upgrade_tools():
    if tool_level>0:show_message("Pro-набор уже куплен.");return
    if cash<3500:show_message("Не хватает 3 500 ₽.");return
    cash-=3500;tool_level=1
    show_message("Pro-инструменты куплены: бонус к оплате ремонтов.")
    update_hud();save_game()

func buy_vehicle():
    if vehicle_level>0:show_message("Транспорт уже приобретён.");return
    if cash<18000:show_message("Нужно 18 000 ₽ на транспорт.");return
    cash-=18000;vehicle_level=1
    player_ref.speed=7.0
    show_message("Электросамокат куплен. Персонаж передвигается быстрее!")
    update_hud();save_game()

func upgrade_shop():
    if shop_level>0:show_message("Мастерская уже улучшена.");return
    if cash<12000:show_message("Нужно 12 000 ₽.");return
    cash-=12000;shop_level=1
    show_message("Рабочее место улучшено. Бонус к ремонту +300 ₽.")
    update_hud();save_game()

func hire_staff():
    if staff_count>0:show_message("Первый мастер уже работает.");return
    if cash<30000:show_message("Нужно 30 000 ₽ для найма.");return
    cash-=30000;staff_count=1
    show_message("Мастер нанят. Каждый новый игровой день приносит пассивный доход.")
    update_hud();save_game()

func show_message(t:String):
    $HUD.set_message(t)

func update_hud():
    $HUD.refresh(cash,reputation,game_day,hour,orders_completed,order_active)

func save_game():
    var d={"cash":cash,"rep":reputation,"day":game_day,"hour":hour,"done":orders_completed,"tools":tool_level,"vehicle":vehicle_level,"shop":shop_level,"staff":staff_count,"revenue":total_revenue,"expenses":total_expenses,"rank":business_rank,"milestone":milestone_paid}
    var f=FileAccess.open(SAVE_PATH,FileAccess.WRITE)
    if f:f.store_string(JSON.stringify(d))

func load_game():
    if not FileAccess.file_exists(SAVE_PATH):return
    var f=FileAccess.open(SAVE_PATH,FileAccess.READ)
    if not f:return
    var d=JSON.parse_string(f.get_as_text())
    if typeof(d)!=TYPE_DICTIONARY:return
    cash=d.get("cash",cash);reputation=d.get("rep",reputation);game_day=d.get("day",game_day);hour=d.get("hour",hour)
    orders_completed=d.get("done",orders_completed);tool_level=d.get("tools",tool_level);vehicle_level=d.get("vehicle",vehicle_level);shop_level=d.get("shop",shop_level);staff_count=d.get("staff",staff_count);total_revenue=d.get("revenue",total_revenue);total_expenses=d.get("expenses",total_expenses);business_rank=d.get("rank",business_rank);milestone_paid=d.get("milestone",milestone_paid)
    if vehicle_level>0:player_ref.speed=7.0
