extends CanvasLayer
var game:Node
var message_label:Label
var cash_label:Label
var info_label:Label
var order_button:Button
var interact_button:Button
var tool_button:Button
var vehicle_button:Button
var shop_button:Button
var staff_button:Button
var time_button:Button
var joystick:Control
var stick:ColorRect
var touch_id=-1
var origin=Vector2.ZERO

func _ready():
    game=get_parent()
    var panel=PanelContainer.new()
    panel.position=Vector2(12,12);panel.size=Vector2(360,110);add_child(panel)
    var v=VBoxContainer.new();panel.add_child(v)
    cash_label=Label.new();cash_label.add_theme_font_size_override("font_size",24);v.add_child(cash_label)
    info_label=Label.new();v.add_child(info_label)
    message_label=Label.new();message_label.position=Vector2(390,16);message_label.size=Vector2(770,82);message_label.add_theme_font_size_override("font_size",19);add_child(message_label)
    order_button=button("ПЛАНШЕТ · Заказ",Vector2(12,135),Vector2(230,48),game.accept_order)
    interact_button=button("ДЕЙСТВИЕ / РЕМОНТ",Vector2(12,190),Vector2(260,48),game.interact)
    tool_button=button("Инструменты · 3 500 ₽",Vector2(12,245),Vector2(250,42),game.upgrade_tools)
    vehicle_button=button("Самокат · 18 000 ₽",Vector2(12,293),Vector2(250,42),game.buy_vehicle)
    shop_button=button("Мастерская · 12 000 ₽",Vector2(12,341),Vector2(250,42),game.upgrade_shop)
    staff_button=button("Нанять мастера · 30 000 ₽",Vector2(12,389),Vector2(275,42),game.hire_staff)
    time_button=button("Пропустить 2 часа →",Vector2(12,437),Vector2(250,42),game.advance_time)
    joystick=Control.new();joystick.position=Vector2(24,get_viewport().get_visible_rect().size.y-210);joystick.size=Vector2(180,180);add_child(joystick)
    var base=ColorRect.new();base.color=Color(.1,.18,.26,.72);base.size=Vector2(165,165);base.position=Vector2(8,8);base.mouse_filter=Control.MOUSE_FILTER_STOP;joystick.add_child(base)
    stick=ColorRect.new();stick.color=Color(.35,.85,.65,.95);stick.size=Vector2(62,62);stick.position=Vector2(59,59);stick.mouse_filter=Control.MOUSE_FILTER_IGNORE;joystick.add_child(stick)
    refresh(game.cash,game.reputation,game.game_day,game.hour,game.orders_completed,game.order_active)

func button(txt,pos,size,callback)->Button:
    var b=Button.new();b.text=txt;b.position=pos;b.size=size;b.add_theme_font_size_override("font_size",15);add_child(b);b.pressed.connect(callback);return b

func refresh(cash,rep,day,hour,done,active):
    if not cash_label:return
    cash_label.text="CargoFix  ·  "+str(cash)+" ₽"
    var gps=" · GPS: заказ не активен"
    if active and game.player_ref:
        var meters=int(game.player_ref.global_position.distance_to(game.client_position))
        gps=" · Клиент "+str(meters)+" м"
    info_label.text="День "+str(day)+" · "+str(int(hour))+":00 · "+game.rank_name()+" · Репутация "+str(rep)+" ★ · Ремонтов "+str(done)+gps
    order_button.text="ПЛАНШЕТ · "+("Заказ активен" if active else "Новая заявка")
    interact_button.text="РЕМОНТ · "+str(game.repair_stage)+"/5 · "+str(game.repair_quality)+"%" if active else "ДЕЙСТВИЕ / РЕМОНТ"
    tool_button.disabled=game.tool_level>0 or cash<3500
    vehicle_button.disabled=game.vehicle_level>0 or cash<18000
    shop_button.disabled=game.shop_level>0 or cash<12000
    staff_button.disabled=game.staff_count>0 or cash<30000

func set_message(t):
    if message_label:message_label.text=t

func _input(event):
    if not joystick:return
    if event is InputEventScreenTouch:
        var p=joystick.get_global_transform().affine_inverse()*event.position
        if event.pressed and Rect2(Vector2.ZERO,joystick.size).has_point(p):
            touch_id=event.index;origin=p;move_stick(p)
        elif not event.pressed and event.index==touch_id:
            touch_id=-1;stick.position=Vector2(59,59);game.player_ref.set_touch_move(Vector2.ZERO)
    elif event is InputEventScreenDrag and event.index==touch_id:
        move_stick(joystick.get_global_transform().affine_inverse()*event.position)

func move_stick(p):
    var d=(p-origin).limit_length(55)
    stick.position=Vector2(59,59)+d
    game.player_ref.set_touch_move(Vector2(d.x/55,d.y/55))
