extends CharacterBody3D

@export var speed: float = 5.0
@export var acceleration: float = 18.0
@export var camera_sensitivity: float = 0.006
var move_vector=Vector2.ZERO
var cam_yaw=0.0
var cam_pitch=-0.22
var camera_drag_id=-1
var last_touch=Vector2.ZERO
var walk_phase=0.0
@onready var body_mesh: MeshInstance3D=$Body
@onready var camera_pivot: Node3D=$CameraPivot

func _physics_process(delta):
    var v=Input.get_vector("left","right","forward","back")
    if move_vector.length()>.08:
        v=move_vector
    var dir=Vector3(v.x,0,v.y).rotated(Vector3.UP,cam_yaw)
    velocity.x=move_toward(velocity.x,dir.x*speed,acceleration*delta)
    velocity.z=move_toward(velocity.z,dir.z*speed,acceleration*delta)
    if not is_on_floor():
        velocity.y-=22*delta
    else:
        velocity.y=-.15
    if dir.length()>.1:
        rotation.y=atan2(-dir.x,-dir.z)
        walk_phase+=delta*11.0*min(dir.length(),1.0)
        body_mesh.position.y=.9+abs(sin(walk_phase))*.07
        body_mesh.rotation.z=sin(walk_phase)*.035
    else:
        body_mesh.position.y=lerp(body_mesh.position.y,.9,delta*8)
        body_mesh.rotation.z=lerp(body_mesh.rotation.z,0.0,delta*8)
    camera_pivot.rotation.y=lerp_angle(camera_pivot.rotation.y,cam_yaw,delta*8)
    camera_pivot.rotation.x=lerp(camera_pivot.rotation.x,cam_pitch,delta*8)
    move_and_slide()

func set_touch_move(v):
    move_vector=v.limit_length(1)

func _input(event):
    if event is InputEventScreenTouch:
        if event.pressed and event.position.x>get_viewport().get_visible_rect().size.x*.42:
            camera_drag_id=event.index
            last_touch=event.position
        elif not event.pressed and event.index==camera_drag_id:
            camera_drag_id=-1
    elif event is InputEventScreenDrag and event.index==camera_drag_id:
        var delta=event.position-last_touch
        last_touch=event.position
        cam_yaw-=delta.x*camera_sensitivity
        cam_pitch=clamp(cam_pitch-delta.y*camera_sensitivity,-.48,.12)
